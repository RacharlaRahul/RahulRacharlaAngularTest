import { Injectable } from '@angular/core';
import { Booking } from 'src/model/Booking';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  booking = [{
    "roomNo": "1",
    "charges": "2000.00"
  }, {
    "roomNo": "2",
    "charges": "2500.00"
  }, {
    "roomNo": "3",
    "charges": "3000.00"
  }];

  constructor() { }

  getAllRoomsForBooking() {
    return this.booking;
  }
}
